﻿using System;

namespace Assignment_5
{
    public class WordReport : IReport
    {
        public void GenerateReport()
        {
            Console.WriteLine("Generating Word Report...");
            // Implementation for generating Word report
        }
    }
}
