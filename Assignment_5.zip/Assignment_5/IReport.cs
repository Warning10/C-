﻿namespace Assignment_5
{
    public interface IReport
    {
        void GenerateReport();
    }
}
