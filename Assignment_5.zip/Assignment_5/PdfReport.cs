﻿using System;

namespace Assignment_5
{
    public class PdfReport : IReport
    {
        public void GenerateReport()
        {
            Console.WriteLine("Generating PDF Report...");
            // Implementation for generating PDF report
        }
    }
}
