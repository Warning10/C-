﻿using System;

namespace Assignment_5
{
    public class ExcelReport : IReport
    {
        public void GenerateReport()
        {
            Console.WriteLine("Generating Excel Report...");
            // Implementation for generating Excel report
        }
    }
}
