﻿namespace Assignment_5
{
    public class ReportManager
    {
        public void GenerateReport(IReport report)
        {
            report.GenerateReport();
        }
    }
}
