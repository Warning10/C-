﻿namespace Assignment_1
{
    public class ImplicitTypeLocalVariable
    {

        public void ImplicitType()
        {
            // Implicitly typed integer
            var age = 25;
            Console.WriteLine("Type of age is {0}", age.GetType());

            // Implicitly typed double
            var temperature = 98.6;
            Console.WriteLine("Type of temperature is {0}", temperature.GetType());

            // Implicitly typed DateTime
            var currentDate = DateTime.Now;
            Console.WriteLine("Type of currentDate is {0}", currentDate.GetType());
        }

    }
}
