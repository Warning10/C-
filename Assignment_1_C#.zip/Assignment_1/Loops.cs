﻿namespace Assignment_1
{
    public class Loops
    {
        public void forLoop()
        {
            Console.WriteLine("---You are in for Loop---");
            Console.WriteLine("\n");

            int i = 0;
            // Example 1: Using for-loop with empty statements.
            Console.WriteLine("Example 1: Using for-loop with empty statements.");
            Console.WriteLine("\n");
            for (; ; )
            {
                if (i > 4)
                {
                    break;
                }
                Console.WriteLine("EMPTY FOR-LOOP: " + i);
                i++;
            }
            Console.WriteLine("\n");
            Console.WriteLine("Press any Key to go for next example.....");
            Console.ReadKey();
            Console.WriteLine("\n");


            // Example 2: Printing a to z
            Console.WriteLine("Example 2: Printing a to z.");
            Console.WriteLine("\n");
            for (char c = 'a'; c <= 'z'; c++)
            {
                Console.Write(c + " ");
            }
            Console.WriteLine("\n");
            Console.WriteLine("Press any Key to go for next example.....");
            Console.ReadKey();
            Console.WriteLine("\n");


            //Example 3: * Pattern

            int j, k, spc, rows;

            Console.WriteLine("Example 3: Display the Patterns like a pyramid with astrick \n");
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("\n");

            Console.Write("Input Number of Rows: ");
            rows = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\n");

            spc = rows + 4 - 1;

            for (i=1; i<=rows; i++)
            {
                for (k=spc; k >= 1; k--)
                {
                    Console.Write(" ");
                }

                for (j=1; j <= i; j++)
                {
                    Console.Write("* ");
                }
                Console.WriteLine("\n");
                spc--;
            }
            Console.WriteLine("Press any Key to go at While Loop.....");
            Console.ReadKey();
            Console.WriteLine("\n");


        }

        public void whileLoop()
        {
            Console.WriteLine("---You are in while Loop---");
            Console.WriteLine("\n");

            // Example: Fibonacci series
            int i, n, j, k;
            Console.WriteLine("Enter a Number for Fibonaci series: ");
            n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\n");
            i = 0;
            j = 1;

            Console.WriteLine($"{i} + {i} = {i}");
            Console.WriteLine($"{i} + {j} = {j}");


            k = i + j;
            while (k <= n)
            {
                Console.WriteLine($"{i} + {j} = {k}");

                i = j;
                j = k;
                k = i + j;
            }

            Console.ReadKey();
        }

        public void doWhileLoopWithSwitch()
        {
            Console.WriteLine("---You are in dowhile Loop---");
            Console.WriteLine("\n");

            char choice;
            int MenuOption;
            int Number1, Number2;

            do
            {
                Console.WriteLine("Press 1 for Addition, 2 for Subtraction, 3 for Multiplication, 4 for Division");
                MenuOption = Convert.ToInt32(Console.ReadLine());
                switch (MenuOption)
                {
                    case 1:
                        Console.WriteLine("Enter the value fo two numbers:");
                        Number1 = Convert.ToInt32(Console.ReadLine());
                        Number2 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine($"Addition is {Number1 + Number2}");
                        break;
                    case 2:
                        Console.WriteLine("Enter the value of Two numbers");
                        Number1 = Convert.ToInt32(Console.ReadLine());
                        Number2 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine($"Subtraction is {Number1 - Number2}");
                        break;
                    case 3:
                        Console.WriteLine("Enter the value of Two numbers");
                        Number1 = Convert.ToInt32(Console.ReadLine());
                        Number2 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine($"Multiplication is {Number1 * Number2}");
                        break;
                    case 4:
                        Console.WriteLine("Enter the value of Two numbers");
                        Number1 = Convert.ToInt32(Console.ReadLine());
                        Number2 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine($"Division is {Number1 / Number2}");
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;

                }

                Console.WriteLine("Please enter Y to continue or any keys to terminate");

                
                string input = Console.ReadLine();
                if (string.IsNullOrEmpty(input))
                {
                    choice = 'N';
                }
                else
                {
                    choice = Convert.ToChar(input);
                }
            } while (Char.ToUpper(choice) == 'Y');

        }

    }
}
