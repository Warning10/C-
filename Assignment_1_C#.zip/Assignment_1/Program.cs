﻿using System;


namespace Assignment_1
{
    internal partial class Program
    {

        
        static void Main(string[] args)
        {

            Loops objLoops = new Loops();
            objLoops.forLoop();
            objLoops.whileLoop();
            objLoops.doWhileLoopWithSwitch();

            ImplicitTypeLocalVariable objVar = new ImplicitTypeLocalVariable();
            objVar.ImplicitType();
        }
    }

}
